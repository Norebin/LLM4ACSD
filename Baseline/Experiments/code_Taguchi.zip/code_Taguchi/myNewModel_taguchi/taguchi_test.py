import numpy as np
import pandas as pd
# 定义一个简单的性能评估函数（在实际应用中，这将是你的模型性能评估函数）
def evaluate_performance(param1, param2, param3, param4, param5, param6):
    # 在这里执行模型训练和性能评估，返回性能得分
    # 这里只是一个示例，实际中你需要根据你的应用来定义评估函数
    performance = param1 * 0.1 + param2 * 0.2 + param3 * 0.15 + param4 * 0.25 + param5 * 0.3 + param6 * 0.3
    return performance

# Taguchi
epoch_values = [100, 200, 300]
hidden_dimension_values = [64, 128, 256]
batch_size_values = [32, 64, 128]
learning_rate_values = [0.01, 0.001, 0.0001]
gcn_layers = [1, 3, 5]
transformer_layers = [1, 3, 5]

# 创建 Taguchi 实验矩阵
experiment_matrix = []
for param1 in epoch_values:
    for param2 in hidden_dimension_values:
        for param3 in batch_size_values:
            for param4 in learning_rate_values:
                for param5 in gcn_layers:
                    for param6 in transformer_layers:
                        experiment_matrix.append([param1, param2, param3, param4, param5, param6])

print(len(experiment_matrix))


# 执行实验并保存结果
results = []
for params in experiment_matrix:
    param1, param2, param3, param4, param5, param6 = params
    performance = evaluate_performance(param1, param2, param3, param4, param5, param6)
    results.append([param1, param2, param3, param4, param5, param6, performance])

# 将结果保存为CSV文件
columns = ['Param1', 'Param2', 'Param3', 'Param4', 'Param5', 'Param6', 'Performance']
df = pd.DataFrame(results, columns=columns)
df.to_csv('taguchi_results.csv', index=False)