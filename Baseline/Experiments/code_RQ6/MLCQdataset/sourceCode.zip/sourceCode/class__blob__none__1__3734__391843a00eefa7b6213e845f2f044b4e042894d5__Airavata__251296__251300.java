    private static class registerDataProduct_resultStandardSchemeFactory implements SchemeFactory {
      public registerDataProduct_resultStandardScheme getScheme() {
        return new registerDataProduct_resultStandardScheme();
      }
    }