    public FacesWebContext(FacesContext context) {
        initialize(context);
    }