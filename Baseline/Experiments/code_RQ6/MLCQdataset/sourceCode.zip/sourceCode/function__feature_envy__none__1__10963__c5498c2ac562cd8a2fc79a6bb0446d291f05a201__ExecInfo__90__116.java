  @Override
  public String toString() {
    return "ExecInfo{"
        + "id='"
        + id
        + '\''
        + ", container="
        + container
        + ", processConfig="
        + processConfig
        + ", openStdout='"
        + openStdout
        + '\''
        + ", openStderr='"
        + openStderr
        + '\''
        + ", openStdin='"
        + openStdin
        + '\''
        + ", running='"
        + running
        + '\''
        + ", exitCode='"
        + exitCode
        + '\''
        + '}';
  }