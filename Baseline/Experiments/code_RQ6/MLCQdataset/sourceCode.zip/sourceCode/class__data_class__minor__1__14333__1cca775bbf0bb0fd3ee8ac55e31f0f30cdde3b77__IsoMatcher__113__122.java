    static class Cause {
        final Tuple<Node> tuple ;
        final Mapping     mapping ;

        public Cause(Tuple<Node> tuple, Mapping mapping) {
            super() ;
            this.tuple = tuple ;
            this.mapping = mapping ;
        }
    }