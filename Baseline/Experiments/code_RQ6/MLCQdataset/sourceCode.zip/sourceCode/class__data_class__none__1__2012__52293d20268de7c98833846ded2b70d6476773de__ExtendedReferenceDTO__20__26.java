public class ExtendedReferenceDTO extends ReferenceDTO {

	public Binder<Object> binder;

	public ServiceTracker<Object, Object> serviceTracker;

}