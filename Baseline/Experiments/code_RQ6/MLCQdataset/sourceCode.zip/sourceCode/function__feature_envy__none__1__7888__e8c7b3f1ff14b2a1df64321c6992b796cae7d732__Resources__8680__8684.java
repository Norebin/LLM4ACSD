      public Builder setPrim(com.android.aapt.Resources.Primitive value) {
        copyOnWrite();
        instance.setPrim(value);
        return this;
        }