    public final void rule__Action__OperatorAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalXtextGrammarTestLanguage.g:6076:1: ( ( ( rule__Action__OperatorAlternatives_2_2_0 ) ) )
            // InternalXtextGrammarTestLanguage.g:6077:2: ( ( rule__Action__OperatorAlternatives_2_2_0 ) )
            {
            // InternalXtextGrammarTestLanguage.g:6077:2: ( ( rule__Action__OperatorAlternatives_2_2_0 ) )
            // InternalXtextGrammarTestLanguage.g:6078:3: ( rule__Action__OperatorAlternatives_2_2_0 )
            {
             before(grammarAccess.getActionAccess().getOperatorAlternatives_2_2_0()); 
            // InternalXtextGrammarTestLanguage.g:6079:3: ( rule__Action__OperatorAlternatives_2_2_0 )
            // InternalXtextGrammarTestLanguage.g:6079:4: rule__Action__OperatorAlternatives_2_2_0
            {
            pushFollow(FOLLOW_2);
            rule__Action__OperatorAlternatives_2_2_0();

            state._fsp--;


            }

             after(grammarAccess.getActionAccess().getOperatorAlternatives_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }