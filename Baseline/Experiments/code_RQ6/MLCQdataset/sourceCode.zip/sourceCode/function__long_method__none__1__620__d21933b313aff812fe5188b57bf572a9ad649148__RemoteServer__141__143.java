    public void setPortStartup(final int portStartup) {
        this.portStartup = portStartup;
    }