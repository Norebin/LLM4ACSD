public interface AdminUserCredentials extends PrincipalCredentials {

}