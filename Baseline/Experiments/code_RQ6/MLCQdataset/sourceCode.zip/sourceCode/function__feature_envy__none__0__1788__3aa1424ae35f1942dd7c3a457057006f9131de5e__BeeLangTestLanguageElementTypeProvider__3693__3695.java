	public IGrammarAwareElementType getModelElementType() {
		return Model_ELEMENT_TYPE;
	}