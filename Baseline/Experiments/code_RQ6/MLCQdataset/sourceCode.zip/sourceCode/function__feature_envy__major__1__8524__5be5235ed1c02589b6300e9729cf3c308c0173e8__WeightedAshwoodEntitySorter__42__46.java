    public WeightedAshwoodEntitySorter() {
        this.weightedDbEntityComparator = new WeightedDbEntityComparator();
        this.weightedObjEntityComparator = new WeightedObjEntityComparator();
        this.entityWeights = Collections.emptyMap();
    }