  @Override
  public void close() {
    bandwidthGaugeUpdater.close();
  }