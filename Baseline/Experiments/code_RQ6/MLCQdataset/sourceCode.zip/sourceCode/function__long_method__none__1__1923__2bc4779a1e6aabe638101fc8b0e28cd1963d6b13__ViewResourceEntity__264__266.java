  public void setViewEntity(ViewEntity view) {
    this.view = view;
  }