    public void setDomainId(Long domainId) {
        this.domainId = domainId;
    }