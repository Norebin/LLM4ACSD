    private LdapConnectionProvider()
    {
        init();
    }