    public static final HashMap createConnectorMap(Options options)
    {
        HashMap connectorMap = new HashMap();
        if (options.isFlagSet('t') > 0)
        {
            //queue is default so only setup map if topic domain is required
            connectorMap.put(JMSConstants.DOMAIN, JMSConstants.DOMAIN_TOPIC);
        }
        return connectorMap;
    }