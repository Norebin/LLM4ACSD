        public void addValue(Object value) {
            this.values.add(value);
        }