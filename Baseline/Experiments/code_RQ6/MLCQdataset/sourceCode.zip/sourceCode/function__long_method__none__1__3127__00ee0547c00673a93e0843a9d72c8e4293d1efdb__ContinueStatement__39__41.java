    public String getLabel() {
        return label;
    }